import { config } from 'dotenv';
config();

import '@/ai/flows/generate-bill-summary.ts';