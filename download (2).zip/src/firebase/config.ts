export const firebaseConfig = {
  "projectId": "studio-5571152152-a8763",
  "appId": "1:333974946501:web:169faa407ac8b2975be6ac",
  "apiKey": "AIzaSyABz4mByLP-R8YGaD-IS0HD0rYbazFKNLA",
  "authDomain": "studio-5571152152-a8763.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "333974946501"
};
